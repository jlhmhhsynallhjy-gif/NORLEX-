
class AppRoutes {
  static const String splash = '/splash';
  static const String welcome = '/welcome';
  static const String login = '/login';
  static const String register = '/register';
  static const String home = '/';
  static const String aiChat = '/ai-chat';
  static const String settings = '/settings';
  static const String profile = '/profile';
  static const String chat = '/chat/:id';
}
